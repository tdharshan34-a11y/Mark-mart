Mark Mart
Unzip this folder and open index.html in any browser (Chrome, Safari, Edge).
On a phone: open index.html, then use "Add to Home Screen" from the browser menu.
Your data is saved in the browser on that device.
